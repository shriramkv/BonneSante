/* eslint-disable jsx-a11y/alt-text */
/* eslint-disable jsx-a11y/img-redundant-alt */
import logo from "./logo.svg";
import "./App.css";
import { useEffect, useState } from "react";
import Papa from "papaparse";
import csvFile from "./data.csv";
import ReactAudioPlayer from "react-audio-player";

function App() {
  const [data, setData] = useState([]);
  const [odata, setOData] = useState([]);
  const [header, setHeader] = useState([]);
  const [selectedData, setSelectedData] = useState([]);
  const [flow , setFlow] = useState(true);

  useEffect(() => {
    Papa.parse(csvFile, {
      download: true,
      complete: function (input) {
        const records = input.data;
        //  console.log(records);
        setData(records);
        setOData(records);
        setHeader(records[0]);
      },
    });
  }, []);

  const handleSelect = (e) => {
    let d = [];
    d.push([]);
    if (e.target.value === "") {
      setData(odata);
    } else {
      for (let i = 0; i < odata.length; i++) {
        const element = odata[i];
        if (element[1] === e.target.value) {
          d.push(element);
        }
      }
      setData(d);
    }
  };

  return (
    <div className="App">
      <div class="d-flex flex-column flex-lg-row h-lg-full bg-surface-secondary">
        <nav
          style={{ minWidth: "270px" }}
          class="navbar show navbar-vertical h-lg-screen navbar-expand-lg px-0 py-3 navbar-light bg-white border-bottom border-bottom-lg-0 border-end-lg"
          id="navbarVertical"
        >
          <div class="container-fluid">
            <button
              class="navbar-toggler ms-n2"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#sidebarCollapse"
              aria-controls="sidebarCollapse"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="navbar-user d-lg-none">
              <div class="dropdown">
                <a
                  href="#"
                  id="sidebarAvatar"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  <div class="avatar-parent-child">
                    <img
                      alt="Image Placeholder"
                      src="https://images.unsplash.com/photo-1548142813-c348350df52b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=3&w=256&h=256&q=80"
                      class="avatar avatar- rounded-circle"
                    />
                    <span class="avatar-child avatar-badge bg-success"></span>
                  </div>
                </a>
                <div
                  class="dropdown-menu dropdown-menu-end"
                  aria-labelledby="sidebarAvatar"
                >
                  <a href="#" class="dropdown-item">
                    Profile
                  </a>
                  <a href="#" class="dropdown-item">
                    Settings
                  </a>
                  <a href="#" class="dropdown-item">
                    Billing
                  </a>
                  <hr class="dropdown-divider" />
                  <a href="#" class="dropdown-item">
                    Logout
                  </a>
                </div>
              </div>
            </div>
            <div class="collapse navbar-collapse" id="sidebarCollapse">
              <ul class="navbar-nav">
                <li style={{ backgroundColor: "#DEDFFD" }} class="nav-item">
                  <a class="nav-link" href="./index.html">
                    <i class="bi bi-house"></i> Dashboard
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="file:///D:/Academics/Hackathon/analytics.html">
                    <i class="bi bi-bar-chart"></i> Analytics
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">
                    <i class="bi bi-chat"></i> Messages
                    <span class="badge bg-soft-primary text-primary rounded-pill d-inline-flex align-items-center ms-auto">
                      6
                    </span>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">
                    <i class="bi bi-people"></i> Users
                  </a>
                </li>
              </ul>
              <hr class="navbar-divider my-5 opacity-20" />

              <div class="mt-auto"></div>
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a class="nav-link" href="#">
                    <i class="bi bi-person-square"></i> Account
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">
                    <i class="bi bi-box-arrow-left"></i> Logout
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        <div class="h-screen flex-grow-1 overflow-y-lg-auto">
          <header class="bg-surface-primary border-bottom pt-6">
            <div class="container-fluid">
              <div style={{ paddingBottom: "30px" }} class="mb-npx">
                <div class="row align-items-center">
                  <div class="col-sm-6 col-12 mb-4 mb-sm-0">
                    <h1 class="h2 mb-0 ls-tight">Patient List</h1>
                  </div>
                  <div class="col-sm-6 col-12 text-sm-end">
                    <div class="mx-n1">
                      <a
                        href="#"
                        class="btn d-inline-flex btn-sm btn-neutral border-base mx-1"
                      >
                        <span class=" pe-2">
                          <i class="bi bi-pencil"></i>
                        </span>
                        <span>Edit</span>
                      </a>
                      <a
                        id='create'
                        data-toggle="modal"
                        data-target="#exampleModalCenter"
                        href="#"
                        class="btn d-inline-flex btn-sm btn-primary mx-1"
                      >
                        <span class=" pe-2">
                          <i class="bi bi-plus"></i>
                        </span>
                        <span>Create</span>
                      </a>
                    </div>
                  </div>
                </div>
                <div
                  class="modal fade"
                  id="exampleModalCenter"
                  tabindex="-1"
                  role="dialog"
                  aria-labelledby="exampleModalCenterTitle"
                  aria-hidden="true"
                >
                  <div
                    class="modal-dialog modal-dialog-centered"
                    role="document"
                  >
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">
                          Patient Details
                        </h5>
                        <button
                          type="button"
                          class="close"
                          data-dismiss="modal"
                          aria-label="Close"
                        >
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div  class="modal-body">
                        <div class="formbold-form-wrapper">
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Patient ID{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              : {selectedData.length > 0 && selectedData[1]}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Gender{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              : {selectedData.length > 0 && selectedData[2]}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Age{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              : {selectedData.length > 0 && selectedData[3]}
                            </h3>
                          </div>

                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Weight{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              : {selectedData.length > 0 && selectedData[4]}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Height{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              :{" "}
                              {(selectedData.length > 0 && selectedData[5]) ||
                                "-"}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Temperature
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              : {selectedData.length > 0 && selectedData[6]}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              BP DISYS{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              : {selectedData.length > 0 && selectedData[7]}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Pulse Rate{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              : {selectedData.length > 0 && selectedData[8]}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              BMI
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              :{" "}
                              {(selectedData.length > 0 && selectedData[9]) ||
                                "-"}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Respiratory Rate{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              : {selectedData.length > 0 && selectedData[10]}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Pulse Volume{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              :{" "}
                              {(selectedData.length > 0 && selectedData[11]) ||
                                "-"}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Pulse Pattern{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              :{" "}
                              {(selectedData.length > 0 && selectedData[12]) ||
                                "-"}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Respiration Rate{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              :{" "}
                              {(selectedData.length > 0 && selectedData[13]) ||
                                "-"}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Somking status{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              :{" "}
                              {(selectedData.length > 0 && selectedData[14]) ||
                                "-"}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Blood Group{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              :{" "}
                              {(selectedData.length > 0 && selectedData[15]) ||
                                "-"}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Chief Complaints Concepts{" "}
                            </h3>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                              :{" "}
                              {(selectedData.length > 0 && selectedData[16]) ||
                                "-"}
                            </h3>
                          </div>
                          <div style={{ display: "flex", margin: "10px" }}>
                            <h3
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-start",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              Audio{" "}
                            </h3>
                            <h3
                            onClick={()=>{console.log("clicked");setFlow(!flow)}}
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-end",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                            
                              {
                                flow ?  <img  style={{width:'20px'}} src={require("./play.png")} /> : <img style={{width:'20px'}}  src={require("./pause.png")} /> 
                              }
                              <span style={{marginLeft:'10px'}}>30 sec</span>
                            </h3>
                            <h3
                            onClick={()=>{console.log("clicked");setFlow(!flow)}}
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-end",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                            
                                <img  style={{width:'20px'}} src={require("./play.png")} /> 
                              

<span style={{marginLeft:'10px'}}>1 min</span>

                              
                            </h3>
                            <h3
                            onClick={()=>{console.log("clicked");setFlow(!flow)}}
                              style={{
                                flex: "0.5",
                                justifyContent: "flex-end",
                                display: "flex",
                                color: "grey",
                                fontSize: "15px",
                              }}
                            >
                              {" "}
                            
                              
                                  <img  style={{width:'20px'}} src={require("./play.png")} /> 
                              
                                                            <span style={{marginLeft:'10px'}}>2 min</span>

                              
                            </h3>
                          </div>
                          
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </header>
          <div id="snackbar">Mail sent successfully</div>
          <main class="py-6 bg-surface-secondary">
            <div class="container-fluid">
              <div class="row g-6 mb-6">
                <div class="col-xl-3 col-sm-6 col-12">
                  <div class="card shadow border-0">
                    <div class="card-body">
                      <div class="row">
                        <div class="col">
                          <span class="h6 font-semibold text-muted text-sm d-block mb-2">
                            Total Patients
                          </span>
                          <span class="h3 font-bold mb-0">21534</span>
                        </div>
                        <div class="col-auto">
                          <div class="icon icon-shape bg-primary text-white text-lg rounded-circle">
                            <i class="bi bi-people"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-3 col-sm-6 col-12">
                  <div class="card shadow border-0">
                    <div class="card-body">
                      <div class="row">
                        <div class="col">
                          <span class="h6 font-semibold text-muted text-sm d-block mb-2">
                            Total Discharged
                          </span>
                          <span class="h3 font-bold mb-0">11534</span>
                        </div>
                        <div class="col-auto">
                          <div class="icon icon-shape bg-warning text-white text-lg rounded-circle">
                            <i class="bi bi-minecart-loaded"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-3 col-sm-6 col-12">
                  <div class="card shadow border-0">
                    <div class="card-body">
                      <div class="row">
                        <div class="col">
                          <span class="h6 font-semibold text-muted text-sm d-block mb-2">
                            Out Patients
                          </span>
                          <span class="h3 font-bold mb-0">5321</span>
                        </div>
                        <div class="col-auto">
                          <div class="icon icon-shape bg-info text-white text-lg rounded-circle">
                            <i class="bi bi-clock-history"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-xl-3 col-sm-6 col-12">
                  <div class="card shadow border-0">
                    <div class="card-body">
                      <div class="row">
                        <div class="col">
                          <span class="h6 font-semibold text-muted text-sm d-block mb-2">
                            ICU Patients
                          </span>
                          <span class="h3 font-bold mb-0">1121</span>
                        </div>
                        <div class="col-auto">
                          <div class="icon icon-shape bg-tertiary text-white text-lg rounded-circle">
                            <i class="bi bi-credit-card"></i>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card shadow border-0 mb-7">
                <div
                  style={{ display: "flex", flexDirection: "row" }}
                  class="card-header"
                >
                  <h5 style={{ flex: "0.5" }} class="mb-0">
                    {" "}
                    Patient List
                  </h5>
                  <div
                    style={{
                      flex: "0.5",
                      display: "flex",
                      justifyContent: "flex-end",
                    }}
                  >
                    <input
                      onChange={handleSelect}
                      style={{ border: "1px solid grey", borderRadius: "9px" }}
                      placeholder="Search Patient"
                    />
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-hover table-nowrap">
                    <thead class="thead-light">
                      <tr>
                        {header &&
                          header.map((t, index) => <th scope="col">{t}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      {Array.isArray(data) &&
                        data.map(
                          (item, index) =>
                            index != 0 && (
                              <tr data-toggle="modal"
                              data-target="#exampleModalCenter" style={{cursor:'pointer'}}
                                onClick={() => {
                                  console.log(item);
                                  setSelectedData(item);
                                }}
                              >
                                {item.map((it1, index) => (
                                  <td>{(it1 && it1) || "-"}</td>
                                ))}
                              </tr>
                            )
                        )}
                    </tbody>
                  </table>
                </div>
                <div class="card-footer border-0 py-5">
                  <span class="text-muted text-sm">
                    Showing 10 items out of 250 results found
                  </span>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}

export default App;
